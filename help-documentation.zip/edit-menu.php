<?php include_once('header.php'); ?>
<div class="wrapper">
	<!-- /.navbar -->
    <?php include_once('top-bar.php'); ?>
  	<!-- Left side column. contains the logo and sidebar -->
    <?php include_once('side-bar.php');?>
	
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper c-w" id="content-in">
	<?php include_once('title-bar.php'); ?>
    <section class="content">
            <div class="row">
                <div class="col-sm-12">
                    <div id="overlayContent"><i class="fa fa-fw fa-spin fa-spinner"></i> Please wait...!</div>
                    <div id="showContent"></div>
                    <?php
                        if(isset($_REQUEST['edit']) and $_REQUEST['edit']!=""){
                            $editID		=	isset($_REQUEST['edit'])?$_REQUEST['edit']:'';
                            $editRow	=	$db->getAllRecords(SS_TB_NAME,'*',' AND id="'.$editID.'"');
							echo '<ol class="breadcrumb breadcrumb-fix" id="breadcrum-home">';
							echo createPath($editRow[0]['id'], SS_TB_NAME);
							echo '</ol>';
                        }
                    ?>
                    <div class="box box-primary" id="menuEditPage">
						<script>
                            $(document).ready(function(e) {
                                $("#createFrom").on("submit",function(){
                                    $('.editorBox').html( tinymce.get('description').getContent() );
                                    title	=	$("#title").val();
                                    if(title!=""){
                                        $.ajax({
                                            type:'POST',
                                            url:'<?php echo SS_URL; ?>ajax/action-form.php',
                                            data:  new FormData(this),
                                            cache: false,
                                            contentType: false,
                                            processData: false,
                                            async: false,
                                            success: function(data){
                                                a =	data.split('|***|');
                                                if(a[1]==1){
                                                    $("#menu-msg").html(a[0]);
													setTimeout(function(){location.reload();},1000);
                                                }else{
                                                    parent.$.colorbox.close();
                                                    $("#menu-msg").html(a[0]);
                                                }
                                            }
                                        });
                                    }
                                });
                                $("#reloadPage").on("click",function(){
                                    goBack();
                                });
                            });
                            function getMenuChild(id,showMenu,frmData,mEditId=""){
                                $(id).on("change",function(){
                                    var curVal	=	$(this).val();
                                    if(curVal!=""){
                                        $(showMenu).show();
                                        $.ajax({
                                            url:'<?php echo SS_URL; ?>ajax/action-form.php?'+frmData+'='+curVal+'&mEditId='+mEditId,
                                            success: function(data){
                                                m	=	data.split('|***|');
                                                if(m[1]==1){
                                                    $(showMenu).html(m[0]);
                                                }else if(m[1]==0){
                                                    $(showMenu).html(m[0]);
                                                }
                                            }
                                        });
                                    }else{
                                        $(showMenu).css('display','none');
                                        $(showMenu).find('select').empty();
                                        $(showMenu).each(function(index, element) {
                                            $(this).find('div[id]').remove();
                                        });
                                    }
                                });
                            }
                        </script>
                    	<form method="post" id="createFrom" onSubmit="return false;">
                            <div class="box-header with-border">
                                <h3 class="box-title"><i class="fa fa-fw fa-pencil"></i> <?php echo isset($editRow[0]['title'])?$editRow[0]['title']:'Edit Menu'; ?></h3>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Hide/Show"><i class="fa fa-minus"></i></button>
                                    <a href="javascript:void(0);" class="btn btn-box-tool" id="reloadPage" data-toggle="tooltip" title="Back"><i class="fa fa-fw fa-reply"></i></a>
                                    <a href="<?php echo SS_URL.$editRow[0]['url']; ?>" class="btn btn-box-tool" data-toggle="tooltip" title="View"><i class="fa fa-fw fa-eye"></i></a>
                                </div>
                            </div>
                            <div class="box-body">
                                <div class="col-sm-12">
                                    <div id="menu-msg"></div>
                                        <input type="hidden" name="editID" value="<?php echo $editID; ?>">
                                        <input type="hidden" name="markParent" id="markParent" value="1">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                	<label>Title</label>
                                                	<div class="input-group">
                                                    	<input type="text" name="title" id="title" class="form-control" value="<?php echo isset($editRow[0]['title'])?$editRow[0]['title']:''; ?>">
                                                    	<div class="input-group-btn"><button type="button" id="mark-parent-btn" class="btn" data-toggle="tooltip" title="Mark as parent">Mark as parent</button></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <script>
                                                        $(document).ready(function(e) {
                                                            getMenuChild("#parent1","#showMenu0","menuReq0","<?php echo $editID; ?>");
                                                        });
                                                    </script>
                                                    <label>Parent Menu</label>
                                                    <select name="parent_id" id="parent1" class="form-control selectpicker" data-live-search="true" <?php if(isset($editRow[0]['parent_id']) and $editRow[0]['parent_id']==0){echo 'disabled';} ?>>
                                                        <option value="">Please select</option>
                                                        <?php
                                                        $menuLevel	=	$db->getAllRecords(SS_TB_NAME,'*',' AND parent_id=0');
                                                            foreach($menuLevel as $rowMenu){
                                                            ?>
                                                            <option value="<?php echo $rowMenu['id']; ?>" <?php if(isset($editRow['parent_id']) and $editRow['parent_id']==$rowMenu['id']){echo 'selected';} ?> ><?php echo stripslashes($rowMenu['title']); ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="row">
                                            <div id="showMenu0"></div>
                                        </div>
                                        <div class="form-group">
                                            <label>Description</label>
                                            <textarea name="description" id="description" class="editorBox"><?php echo isset($editRow[0]['description'])?html_entity_decode(stripslashes($editRow[0]['description'])):''; ?></textarea>
                                        </div>
                                </div> <!--/.col-sm-12-->
                            </div>
                            <div class="box-footer">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <button type="submit" name="update" class="btn btn-primary">UPDATE</button>
                                        <a href="<?php echo SS_URL.$editRow[0]['url']; ?>" class="btn btn-danger">CANCEL</a>
                                    </div>
                                </div>
                            </div>
	                    </form>
                    </div>
                </div>
            </div>
    </section>
</div>
<?php include_once('footer.php'); ?>