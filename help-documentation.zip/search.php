<?php include_once('header.php'); ?>
<div class="wrapper">
	<!-- /.navbar -->
    <?php include_once('top-bar.php'); ?>
  	<!-- Left side column. contains the logo and sidebar -->
    <?php include_once('side-bar.php'); ?>
	
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper c-w" id="content-in">
	<?php include_once('title-bar.php'); ?>
	<section class="content">
        <div class="row">
        	<div class="col-sm-12">
            	<div id="overlayContent"><i class="fa fa-fw fa-spin fa-spinner"></i> Please wait...!</div>
                <div id="showContent"></div>
                <div class="box box-primary" id="searchPage">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-fw fa-search"></i> <?php echo stripslashes(ucfirst(str_replace("-"," ",$_REQUEST['str']))); ?></h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Hide/Show"><i class="fa fa-minus"></i></button>
                        </div>
                    </div> <!-- /.box-header -->
                    <div class="box-body">
                        <div class="row">
                            <?php
                                $condition	=	'';
                                if(isset($_REQUEST['str']) and $_REQUEST['str']!=""){
                                    $condition	.=	" AND (LOWER(title) LIKE '%".strtolower(str_replace("-"," ",$_REQUEST['str']))."%') ";
                                }
                                if(isset($_REQUEST['str']) and $_REQUEST['str']!=""){
                                    $condition	.=	" OR (LOWER(description) LIKE '%".strtolower(str_replace("-"," ",$_REQUEST['str']))."%') ";
                                }
                                $qryStr		=	"SELECT * FROM ".SS_TB_NAME." WHERE 1 ".$condition." ORDER BY title ASC"; 
                                $rest		=	$db->getRecFrmQry($qryStr);
                                $count		=	count($rest);
                                if($count>0){
                            ?>
                            <div class="col-sm-12 search-list">
                                <ul class="products-list product-list-in-box">
                                <?php
                                    foreach($rest as $sRow){
                                        $mStr 		= 	stripslashes($sRow['title']);
                                        $keyword 	= 	str_replace("-"," ",$_REQUEST['str']);
                                        $mStr 		= 	preg_replace("/\b([a-z]*${keyword}[a-z]*)\b/i","<span class='find'>$1</span>",$mStr);
									?>
                                    <li class="item">
                                        <a href="javascript:void(0);" data-href="<?php echo SS_URL.'ajax/popup/'.$sRow['id'].'.html'; ?>" class="product-title openPopup"><i class="fa fa-fw fa-angle-right"></i> <?php echo $mStr; ?></a>
                                    </li>
                                <?php } ?>
                                </ul>
                            </div>
                            <?php }else{ ?>
                            <div class="col-sm-12">
                                <p>Your search did not match any documents. Please make sure that all words are spelled correctly.</p>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
			</div>
        </div> <!--/.row-->
    </section> <!-- /.content -->
    
</div> <!-- /.content-wrapper -->
<!-- Modal -->
<div class="modal fade" id="searchModal" role="dialog">
    <div class="modal-dialog modal-xl">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><i class="fa fa-fw fa-search"></i> Search content</h4>
            </div>
            <div class="modal-body">
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
            </div>
        </div>
      
    </div>
</div>

    <div class="control-sidebar-bg"></div>
    
</div> <!-- ./wrapper -->

<?php include_once('footer.php'); ?>