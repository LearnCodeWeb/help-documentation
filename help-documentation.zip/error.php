<?php include_once('config/config.php');
//print_r($_REQUEST);
#header("HTTP/1.1 301 Moved Permanently");
header_redirect(SS_URL.'error/404.html');
//header('Location: '.SS_URL.'error/404.html');
exit();
?>