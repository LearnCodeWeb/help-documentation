<?php
include_once('config/config.php');
include_once('config/validation.php');

if(isset($_REQUEST['v']) and $_REQUEST['v']!="view-menu"){ include_once(SS_PATH.'error.php'); exit; }
if(isset($_REQUEST['str']) and $_REQUEST['s']!="result"){ include_once(SS_PATH.'error.php'); exit; }
if(isset($_REQUEST['menuID']) and $_REQUEST['menuID']!="create-menu"){ include_once(SS_PATH.'error.php'); exit; }
if(isset($_REQUEST['menuEdit']) and $_REQUEST['menuEdit']!="menu-edit"){ include_once(SS_PATH.'error.php'); exit; }
if(isset($_REQUEST['id']) and $_REQUEST['name']!=""){
	$mainID	=	isset($_REQUEST['id'])?$_REQUEST['id']:'';
	$getUrl	=	$db->getAllRecords(SS_TB_NAME,'url',' AND id="'.$mainID.'"');
	$url	=	explode("/",$getUrl[0]['url']);
	if(str_replace(".html","",$url[2])!=$_REQUEST['name']){
		include_once(SS_PATH.'error.php'); exit;
	}
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" value="text/html; charset=UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php if(isset($_REQUEST['v']) and $_REQUEST['v']=="view-menu"){ echo 'View Menu';} if(isset($_REQUEST['str']) and $_REQUEST['s']=="result"){ echo 'Search';} if(isset($_REQUEST['menuID']) and $_REQUEST['menuID']=="create-menu"){ echo 'Create menu';} if(isset($_REQUEST['menuEdit']) and $_REQUEST['menuEdit']=="menu-edit"){echo getMenuTitle($_REQUEST['edit']);} if(isset($_REQUEST['id']) and $_REQUEST['name']!=""){echo getMenuTitle($_REQUEST['id']);} ?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/css/dashbordFWT.min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/css/bootstrap-select.min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/css/datepicker3.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/css/hover-min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/colorbox/theme3/colorbox.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/css/all.min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/prismjs/prism.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/css/style.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<body class="sidebar-mini skin-blue">
<script src="<?php echo SS_URL; ?>custom/js/jquery.min.js"></script>