<?php include_once('config/config.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" value="text/html; charset=UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Reinstall Documentation Panel</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/css/dashbordFWT.min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/css/all.min.css">
  <link rel="stylesheet" href="<?php echo SS_URL; ?>custom/css/style.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<?php
$getQry	=	$db->getRecFrmQry("SELECT * FROM information_schema.tables WHERE table_schema='".SS_DB_NAME."' AND table_name='".SS_TB_NAME."' LIMIT 1");
if(count($getQry)>0){
	header_redirect(SS_URL);
	exit;
}

if(isset($_REQUEST['reinstall']) and $_REQUEST['reinstall']=='ok'){
	if(file_exists(SS_PATH.'config/database.php')){
		unlink(SS_PATH.'config/database.php');
		header_redirect(SS_URL);
		exit;
	}elseif(!file_exists(SS_PATH.'config/database.php')){
		header_redirect(SS_URL);
		exit;
	}
}
?>
<body class="wrapper-installer">

<!-- Content Wrapper. Contains page content -->
<div class="installer">
	<section class="content">
        <div class="row">
            <div class="col-sm-12">
            	<div class="box box-primary mt-4" id="contentPage">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-fw fa-database"></i> Re-Installation</h3>
                    </div> <!-- /.box-header -->
                    <div class="box-body">
                        <div class="row">
                            <div class="col-sm-12 text-center">
	                            <div class="callout callout-danger">
                                    <i class="fa fa-fw fa-exclamation-triangle"></i> We didn't found Database or Table!
                                </div>
                                <p>If you view this message then system didn't found <strong>Database</strong> name (<?php echo SS_DB_NAME; ?>)</p>
                                <p><kbd>OR</kbd></p>
                                <p><strong>Table</strong> name (<?php echo SS_TB_NAME; ?>).</p>
                                <p>You need to reinstall the system. Befor reinstallation the system, you need to take a backup of your <strong>FILES</strong>!</p>
                                <p>Click on a below button to reinstall.</p>
                                <a href="<?php echo $_SERVER['PHP_SELF']; ?>?reinstall=ok" class="btn btn-primary">Reinstall</a>
                            </div>
                        </div> <!-- /.row -->
                    </div> <!-- ./box-body -->
                </div>
            </div>
        </div>
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->

</body>
</html>
