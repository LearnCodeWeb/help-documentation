<?php
error_reporting(0);
session_start();
$base_url 	= 	((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http"). "://". @$_SERVER['HTTP_HOST'];
$base_path 	= 	dirname(__DIR__).'/';

$path 			= 	parse_url($base_path, PHP_URL_PATH);
$pathFragments 	= 	explode('\\', $path);
$end 			= 	end($pathFragments);

define('SS_PATH', $base_path);
define('SS_FWT', $base_url.'/');
define('SS_URL', $base_url.'/'.$end);
define('remove','../'); //FIX tinymce filemanager path for showing files.

$_SESSION['mainDir']	=	$end;

include_once(SS_PATH.'classes/Database.php');

if(file_exists(SS_PATH.'config/database.php')){
	include_once(SS_PATH.'config/database.php');
	$dsn	= 	"mysql:dbname=".SS_DB_NAME.";host=".SS_DB_HOST."";
	$pdo	=	"";
	try {$pdo = new PDO($dsn, SS_DB_USER, SS_DB_PASSWORD);} catch (PDOException $e) {echo "Connection failed: " . $e->getMessage();}
	$db 	=	new Database($pdo);
}elseif(!file_exists(SS_PATH.'config/database.php')){
	header("location: ".SS_URL."");
	exit;
}

include_once(SS_PATH.'classes/paginator.class.php');
include_once(SS_PATH.'function/functions.php');
