<?php include_once('config.php');
$getQry	=	$db->getRecFrmQry("SELECT * FROM information_schema.tables WHERE table_schema='".SS_DB_NAME."' AND table_name='".SS_TB_NAME."' LIMIT 1");
if(count($getQry)<=0){
	header_redirect(SS_URL.'installation-error/reinstall.html');
	exit;
}
?>