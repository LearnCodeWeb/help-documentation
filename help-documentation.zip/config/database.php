<?php 
 define('SS_DB_NAME', 'documentation');
 define('SS_DB_USER', 'root');
 define('SS_DB_PASSWORD', '');
 define('SS_DB_HOST', 'localhost');
 define('SS_TB_NAME','tb_help_menu');
