<?php include_once('header.php'); ?>
<div class="wrapper">
	<!-- /.navbar -->
    <?php include_once('top-bar.php'); ?>
  	<!-- Left side column. contains the logo and sidebar -->
    <?php include_once('side-bar.php');?>
    
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper c-w" id="content-in">
	<?php include_once('title-bar.php'); ?>
    <section class="content">
        <div class="row">
            <div class="col-sm-12">
            	<div id="overlayContent"><i class="fa fa-fw fa-spin fa-spinner"></i> Please wait...!</div>
                <div id="showContent"></div>
                	<?php
					if(isset($_REQUEST['id']) and $_REQUEST['id']!=""){
						$mainID	=	isset($_REQUEST['id'])?$_REQUEST['id']:'';
						$row	=	$db->getAllRecords(SS_TB_NAME,'*',' AND id="'.$mainID.'"');
						echo '<ol class="breadcrumb breadcrumb-fix" id="breadcrum-home">';
						echo createPath($row[0]['id'], SS_TB_NAME);
						echo '</ol>';
					?>
				    <div class="box box-primary" id="contentPage">
                        <div id="overlay"></div>
                        <script>
                            $(document).ready(function(e) {
                                $("#find-img").find('img').each(function(index, element) {
                                    $(this).addClass('img-responsive img-thumbnail');
                                });
								
								//Create clone
								$("#clone_<?php echo $row[0]['id']; ?>").on("click",function(){
									if(confirm('Are you sure to create Raplica/Copy of this page?')){
										$.ajax({
											type:'POST',
											url:'<?php echo SS_URL; ?>ajax/action-form.php',
											data:{'clone':'ok','id':'<?php echo $row[0]['id']; ?>'},
											success: function(data){
												a	=	data.split('|***|');
												if(a[1]==1){
													window.location.href=a[0];
												}else{
													$("#clone-msg").html(a[0]);
												}
											}
										});
									}else{
										return false;
									}
								});
                            });
                        </script>
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fa fa-fw fa-file"></i> <?php echo isset($row[0]['title'])?$row[0]['title']:''; ?></h3>
                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Hide/Show"><i class="fa fa-minus"></i></button>
                            	
                                <a href="<?php echo SS_URL.'edit/'.$row[0]['id'].'/menu-edit.html'; ?>" class="btn btn-box-tool" data-toggle="tooltip" title="Edit"><i class="fa fa-fw fa-pencil"></i></a>
                                <a href="javascript:void(0);" id="clone_<?php echo $row[0]['id']; ?>" class="btn btn-box-tool" data-toggle="tooltip" title="Clone"><i class="fa fa-fw fa-clone"></i></a>
                            </div>
                        </div> <!-- /.box-header -->
                        <div class="box-body">
                        	<div id="clone-msg"></div>
                            <div class="row">
                                <div class="col-sm-12" id="find-img">
                                    <?php echo isset($row[0]['description'])?html_entity_decode(stripslashes($row[0]['description'])):''; ?>
                                </div>
                            </div> <!-- /.row -->
                        </div> <!-- ./box-body -->
                        <div class="box-footer">
                            <div class="row">
                                <div class="col-sm-12 col-xs-12 text-right">
                                    <h5 class="description-header"><i class="fa fa-fw fa-user"></i> <?php echo isset($row[0]['user'])?ucfirst($row[0]['user']):''; ?></h5>
                                    <span class="description-text"><i class="fa fa-fw fa-clock-o"></i> <?php echo isset($row[0]['dt'])?$row[0]['dt']:''; ?></span>
                                </div> <!-- /.col -->
                            </div> <!-- /.row -->
                        </div> <!-- /.box-footer -->
                    </div> <!-- /.box -->
                    <?php } ?>
            </div>
        </div>
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->

  	<div class="control-sidebar-bg"></div>
    
</div> <!-- ./wrapper -->


<?php include_once('footer.php'); ?>