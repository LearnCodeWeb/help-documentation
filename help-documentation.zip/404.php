<?php include_once('header.php'); ?>
<div class="wrapper">
	<!-- /.navbar -->
    <?php include_once('top-bar.php'); ?>
  	<!-- Left side column. contains the logo and sidebar -->
    <?php include_once('side-bar.php'); ?>
	
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper c-w" id="content-in">
	<?php include_once('title-bar.php'); ?>
    <section class="content">
        <div class="row">
            <div class="col-sm-12">
            	<div id="overlayContent"><i class="fa fa-fw fa-spin fa-spinner"></i> Please wait...!</div>
                <div id="showContent"></div>
				<?php
                if(isset($_REQUEST['sSubmit'])){
                    $searchStr	=	clean($_REQUEST['search']);
					header_redirect(SS_URL.'search/'.clean($searchStr).'/result.html');
                    //header('location:'.SS_URL.'search/'.clean($searchStr).'/result.html');
                    exit;
                }
                ?>
                <div class="text-center form404" id="form404">
                    <h1><i class="fa fa-fw fa-frown-o"></i> Are you lost? </h1>
                    <form method="post">
                        <div class="mt-1">
                            <div class="input-group">
                                <input type="text" class="form-control" autocomplete="off" required value="<?php echo isset($_REQUEST['str'])?$_REQUEST['str']:''; ?>" name="search" id="search" placeholder="Search by string">
                                <span class="input-group-btn"><button type="submit" name="sSubmit" class="btn btn-primary"><i class="fa fa-fw fa-search"></i></button></span>
                            </div>
                        </div>
                    </form>
                	<div class="text-center img404 mt-4"><img src="<?php echo SS_URL; ?>custom/images/404.png" /></div>
                </div>
            </div>
        </div>
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->

  	<div class="control-sidebar-bg"></div>
    
</div> <!-- ./wrapper -->

<?php include_once('footer.php'); ?>