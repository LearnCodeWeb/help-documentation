    <?php
		if(isset($_REQUEST['sSubmit'])){
			$searchStr	=	clean($_REQUEST['search']);
			header_redirect(SS_URL.'search/'.clean($searchStr).'/result.html');
			exit;
		}
	?>
	<script>
	function menuCall(menuId,menuUrl,menuTitle,overlayContent,baseUrl){
		$('#'+menuId).click(function() {
			window.history.pushState("", "", baseUrl+menuUrl);
			changeTitle(menuTitle);
			listCont	=	0;
			$(overlayContent).show();
			$.ajax({
				url:''+baseUrl+'ajax/content/'+menuId+'.html',
				success: function(data){
					if(data!=""){
						$("#showContent").html(data);
						$("#menuPage, #searchPage, #contentPage, #createMenuPage, #form404, #menuEditPage, #breadcrum-home").remove();
						$("#overlayContent").hide();
						$("#search").val('');
						$(window).scrollTop(0);
					}
					setTimeout(function(){
						listCont	=	$("ul.sidebar-menu").find('li.active').find('ul.treeview-menu > li').not('ul.treeview-menu > li ul.treeview-menu > li').size();
						if(listCont>23){
							$("ul.sidebar-menu").addClass('list-treeview-fix');
						}else{
							$("ul.sidebar-menu").removeClass('list-treeview-fix');
						}
						console.log(listCont);
					},500);
				}
			});
		});
	}
	</script>
    <aside class="main-sidebar m-s">
        <div class="left-nave">
            <!-- Logo -->
            <a href="<?php echo SS_URL; ?>" class="logo">
                <span class="logo-lg">&nbsp;</span>
            </a>
            <!-- sidebar: style can be found in sidebar.less -->
            <section class="sidebar">
                <form method="post" class="sidebar-form no-border">
                    <div class="mt-1">
                        <div class="input-group">
                            <input type="text" class="form-control" autocomplete="off" required="required" value="<?php echo isset($_REQUEST['str'])?(str_replace("-"," ",$_REQUEST['str'])):''; ?>" name="search" id="search" placeholder="Search by string" <?php if(isset($_REQUEST['str']) and $_REQUEST['str']!=""){?>autofocus="autofocus" onfocus="var temp_value=this.value; this.value=''; this.value=temp_value" <?php } ?>>
                            <span class="input-group-btn"><button type="submit" name="sSubmit" title="Search" class="btn btn-primary"><i class="fa fa-fw fa-search"></i></button><button type="button" class="btn btn-danger" title="Reset" onclick="window.location.href='<?php echo SS_URL; ?>'"><i class="fa fa-fw fa-refresh"></i></button></span>
                        </div>
                    </div>
                </form>
                <?php
                $sql	=	$db->getRecFrmQry('SELECT id as menu_item_id, parent_id as menu_parent_id, title as menu_item_name,url,icon FROM '.SS_TB_NAME.' ORDER BY menu_order,id ASC');
                $refs 	= array();
                $list 	= array();
                foreach($sql	as $data){
                    $thisref = &$refs[ $data['menu_item_id'] ];
                    $thisref['menu_parent_id'] = $data['menu_parent_id'];
                    $thisref['menu_item_name'] = $data['menu_item_name'];
                    $thisref['url'] 	= 	$data['url'];
                    $thisref['icon'] 	= 	$data['icon'];
                    if ($data['menu_parent_id'] == 0){
                        $list[ $data['menu_item_id'] ] = &$thisref;
                    }else{
                        $refs[ $data['menu_parent_id'] ]['children'][ $data['menu_item_id'] ] = &$thisref;
                    }
                }
                $reqID	=	isset($_REQUEST['id'])?$_REQUEST['id']:'';
                echo createMenu($list,0,$reqID);
                ?>
                <?php if(isset($_REQUEST['id'])){ ?>
                <script>
                    $(document).ready(function(e) {
                        $(".treeview").each(function() {
                            $(this).find('li.active').parents('.treeview').addClass('active');
                        });
                    });
                </script>
                <?php } ?>
            </section>
            <!-- /.sidebar -->
        </div>
        <div class="left-nav-footer">
        	V 1.0 <i class="fa fa-fw fa-copyright"></i> All Rights Reserved.
        </div>
    </aside>
