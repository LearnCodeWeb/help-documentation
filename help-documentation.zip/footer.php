<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="<?php echo SS_URL; ?>bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo SS_URL; ?>custom/js/bootstrap-select.min.js"></script>
<script src="<?php echo SS_URL; ?>custom/js/bootstrap-datepicker.js"></script>
<script src="<?php echo SS_URL; ?>custom/js/app.js"></script>
<script src="<?php echo SS_URL; ?>custom/colorbox/jquery.colorbox-min.js"></script>
<script src="<?php echo SS_URL; ?>custom/tinymce/tinymce.min.js"></script>
<script src="<?php echo SS_URL; ?>custom/prismjs/prism.js"></script>
<script src="<?php echo SS_URL; ?>custom/js/custom.js"></script>

</body>
</html>
