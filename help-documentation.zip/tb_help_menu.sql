-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2018 at 04:14 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `document`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_help_menu`
--

CREATE TABLE `tb_help_menu` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `url` text NOT NULL,
  `status` tinyint(1) DEFAULT '1',
  `icon` varchar(100) DEFAULT NULL,
  `menu_order` tinyint(4) DEFAULT NULL,
  `description` text NOT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_help_menu`
--

INSERT INTO `tb_help_menu` (`id`, `parent_id`, `title`, `url`, `status`, `icon`, `menu_order`, `description`, `dt`, `user`) VALUES
(2, 0, 'Multi level menu', 'page/2/multi-level-menu.html', 1, NULL, 1, '&lt;p&gt;I am first level menu. You can call me first level menu :)&lt;/p&gt;', '2018-02-25 19:28:00', 'sysadmin'),
(3, 2, 'First level menu', 'page/3/first-level-menu.html', 1, NULL, 0, '', '2018-02-25 19:28:08', 'sysadmin'),
(4, 2, 'First level menu', 'page/4/first-level-menu.html', 1, NULL, 0, '', '2018-02-22 21:40:50', 'sysadmin'),
(5, 2, 'First level menu', 'page/5/first-level-menu.html', 1, NULL, 0, '', '2018-02-22 21:42:08', 'sysadmin'),
(6, 5, 'Second level child', 'page/6/second-level-child.html', 1, NULL, 0, '&lt;p&gt;I am a first level child menu.&lt;/p&gt;', '2018-02-25 16:35:04', 'sysadmin'),
(7, 5, 'Second level child', 'page/7/second-level-child.html', 1, NULL, 0, '', '2018-02-25 15:31:00', 'sysadmin'),
(8, 5, 'Second level child', 'page/8/second-level-child.html', 1, NULL, 0, '', '2018-02-25 19:26:32', 'sysadmin'),
(11, 8, 'Third level child', 'page/11/third-level-child.html', 1, NULL, 0, '', '2018-02-25 19:28:27', 'sysadmin'),
(12, 8, 'Third level child', 'page/12/third-level-child.html', 1, NULL, 0, '', '2018-02-22 21:43:56', 'sysadmin'),
(13, 8, 'Third level child', 'page/13/third-level-child.html', 1, NULL, 0, '', '2018-02-22 21:44:07', 'sysadmin'),
(18, 0, 'Second menu', 'page/18/second-menu.html', 1, NULL, 2, '&lt;p&gt;Test&lt;/p&gt;', '2018-02-22 23:10:19', 'sysadmin'),
(19, 18, 'Level one', 'page/19/level-one.html', 1, NULL, 0, '', '2018-02-25 15:23:19', 'sysadmin'),
(20, 18, 'Level one', 'page/20/level-one.html', 1, NULL, 0, '', '2018-02-25 15:23:33', 'sysadmin'),
(21, 18, 'Level one', 'page/21/level-one.html', 1, NULL, 0, '', '2018-02-25 15:23:45', 'sysadmin'),
(22, 21, 'Level Two', 'page/22/level-two.html', 1, NULL, 0, '', '2018-02-25 15:24:04', 'sysadmin'),
(23, 21, 'Level Two', 'page/23/level-two.html', 1, NULL, 0, '', '2018-02-25 15:24:17', 'sysadmin'),
(24, 21, 'Level Two', 'page/24/level-two.html', 1, NULL, 0, '', '2018-02-25 15:24:33', 'sysadmin'),
(25, 24, 'Level Three', 'page/25/level-three.html', 1, NULL, 0, '', '2018-02-25 15:24:48', 'sysadmin'),
(26, 24, 'Level Three', 'page/26/level-three.html', 1, NULL, 0, '', '2018-02-25 15:25:02', 'sysadmin'),
(27, 24, 'Level Three', 'page/27/level-three.html', 1, NULL, 0, '', '2018-02-25 15:25:40', 'sysadmin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_help_menu`
--
ALTER TABLE `tb_help_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_help_menu`
--
ALTER TABLE `tb_help_menu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
