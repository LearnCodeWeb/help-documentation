<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" value="text/html; charset=UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Installation of Documentation Panel</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="custom/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="custom/css/dashbordFWT.min.css">
  <link rel="stylesheet" href="custom/css/style.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<body class="wrapper-installer">
<script src="custom/js/jquery.min.js"></script>
<div>
	
<!-- Content Wrapper. Contains page content -->
<div class="installer">
	<section class="content">
        <div class="row">
            <div class="col-sm-12">
            	<?php if(isset($_REQUEST['dbError']) and $_REQUEST['dbError']=="ok"){ ?>
                <div class="box box-primary mt-4">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-fw fa-database"></i> Error establishing a database connection</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Hide/Show"><i class="fa fa-minus"></i></button>
                        </div>
                    </div> <!-- /.box-header -->
                    <div class="box-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <p>Connection not establish with your <strong>DATABASE SERVER</strong>. Please try again.</p>
                                <ol>
                                    <li>Do you have the correct username and password?</li>
                                    <li>Are you sure that you have typed the correct hostname?</li>
                                    <li>Are you sure that the database server is running?</li>
                                </ol>
                                <p><a href="?tryagain=ok" class="btn btn-default">Try again</a></p>
                            </div>
                        </div> <!-- /.row -->
                    </div> <!-- ./box-body -->
                </div>
                <?php }else{ ?>
                <div class="box box-primary mt-4">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-fw fa-database"></i> Installation</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Hide/Show"><i class="fa fa-minus"></i></button>
                        </div>
                    </div> <!-- /.box-header -->
                    <div class="box-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <p>Welcome to <strong>Documentation Panel</strong>. Before getting started, we need some information on the database. You will need to know the following items before proceeding.</p>
                                <ol>
                                    <li>Database name</li>
                                    <li>Database username</li>
                                    <li>Database password</li>
                                    <li>Database host</li>
                                </ol>
                                <p>Below you should enter your database connection details. If you’re not sure about these, contact your host.</p>
                                <?php
								if(file_exists('config/database.php')){
									header("HTTP/1.1 301 Moved Permanently");
									header("location: view/view-menu.html");
									exit;
								}else{
									
									if(isset($_REQUEST['create'])){
										extract($_REQUEST);
										$link = mysqli_connect($dbhost, $uname, $pwd, $dbname);
										
										if(!$link){
											header('location: ?dbError=ok');
											exit;
										}else{
											$configFile = 	'config/database.php';
											$handle 	= 	fopen($configFile, 'a') or die('Cannot open file:  '.$configFile);
											$newData 	= 	"<?php \n define('SS_DB_NAME', '".$dbname."');\n define('SS_DB_USER', '".$uname."');\n define('SS_DB_PASSWORD', '".$pwd."');\n define('SS_DB_HOST', '".$dbhost."');\n define('SS_TB_NAME','".$tbname."');\n";
											fwrite($handle,$newData);
										}
										
										$getQry	=	mysqli_query($link,"SELECT * FROM information_schema.tables WHERE table_schema='".$dbname."' AND table_name='".$tbname."' LIMIT 1") or die("Select query: " . mysqli_error());
										if(mysqli_num_rows($getQry)>0){
											header("location: view/view-menu.html");
											exit;
										}else{
											mysqli_query($link,"CREATE TABLE `".$tbname."` (
														`id` BIGINT UNSIGNED NOT NULL,
														`parent_id` BIGINT UNSIGNED NOT NULL DEFAULT '0',
														`title` text NOT NULL DEFAULT '',
														`url` text NOT NULL DEFAULT '',
														`status` tinyint(1) DEFAULT '1',
														`icon` varchar(100) DEFAULT NULL,
														`menu_order` tinyint(4) DEFAULT NULL,
														`description` text NOT NULL,
														`dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
														`user` varchar(32) NOT NULL
											)") or die("Create Query: " . mysqli_error());
											
											mysqli_query($link,"ALTER TABLE `".$tbname."` ADD PRIMARY KEY (`id`)") or die("Primary key: " . mysqli_error());
											mysqli_query($link,"ALTER TABLE `".$tbname."` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT") or die("Primary key update auto increment: " . mysqli_error());
										}
										
										$getQry	=	mysqli_query($link,"SELECT * FROM `".$tbname."`") or die("Select query: " . mysqli_error());
										if(mysqli_num_rows($getQry)>0){
											header("location: view/view-menu.html");
											exit;
										}else{
											mysqli_query($link,"INSERT INTO `".$tbname."` (`id`, `parent_id`, `title`, `url`, `status`, `icon`, `menu_order`, `description`, `dt`, `user`) VALUES
											(2, 0, 'Multi level menu', 'page/2/multi-level-menu.html', 1, NULL, 1, '&lt;p&gt;I am first level menu. You can call me first level menu :)&lt;/p&gt;', '2018-02-26 04:28:00', 'sysadmin'),
											(3, 2, 'First level menu', 'page/3/first-level-menu.html', 1, NULL, '', '', '2018-02-26 04:28:08', 'sysadmin'),
											(4, 2, 'First level menu', 'page/4/first-level-menu.html', 1, NULL, '', '', '2018-02-23 06:40:50', 'sysadmin'),
											(5, 2, 'First level menu', 'page/5/first-level-menu.html', 1, NULL, '', '', '2018-02-23 06:42:08', 'sysadmin'),
											(6, 5, 'Second level child', 'page/6/second-level-child.html', 1, NULL, '', '&lt;p&gt;I am a first level child menu.&lt;/p&gt;', '2018-02-26 01:35:04', 'sysadmin'),
											(7, 5, 'Second level child', 'page/7/second-level-child.html', 1, NULL, '', '', '2018-02-26 00:31:00', 'sysadmin'),
											(8, 5, 'Second level child', 'page/8/second-level-child.html', 1, NULL, '', '', '2018-02-26 04:26:32', 'sysadmin'),
											(11, 8, 'Third level child', 'page/11/third-level-child.html', 1, NULL, '', '', '2018-02-26 04:28:27', 'sysadmin'),
											(12, 8, 'Third level child', 'page/12/third-level-child.html', 1, NULL, '', '', '2018-02-23 06:43:56', 'sysadmin'),
											(13, 8, 'Third level child', 'page/13/third-level-child.html', 1, NULL, '', '', '2018-02-23 06:44:07', 'sysadmin'),
											(18, 0, 'Second menu', 'page/18/second-menu.html', 1, NULL, 2, '&lt;p&gt;Test&lt;/p&gt;', '2018-02-23 08:10:19', 'sysadmin'),
											(19, 18, 'Level one', 'page/19/level-one.html', 1, NULL, '', '', '2018-02-26 00:23:19', 'sysadmin'),
											(20, 18, 'Level one', 'page/20/level-one.html', 1, NULL, '', '', '2018-02-26 00:23:33', 'sysadmin'),
											(21, 18, 'Level one', 'page/21/level-one.html', 1, NULL, '', '', '2018-02-26 00:23:45', 'sysadmin'),
											(22, 21, 'Level Two', 'page/22/level-two.html', 1, NULL, '', '', '2018-02-26 00:24:04', 'sysadmin'),
											(23, 21, 'Level Two', 'page/23/level-two.html', 1, NULL, '', '', '2018-02-26 00:24:17', 'sysadmin'),
											(24, 21, 'Level Two', 'page/24/level-two.html', 1, NULL, '', '', '2018-02-26 00:24:33', 'sysadmin'),
											(25, 24, 'Level Three', 'page/25/level-three.html', 1, NULL, '', '', '2018-02-26 00:24:48', 'sysadmin'),
											(26, 24, 'Level Three', 'page/26/level-three.html', 1, NULL, '', '', '2018-02-26 00:25:02', 'sysadmin'),
											(27, 24, 'Level Three', 'page/27/level-three.html', 1, NULL, '', '', '2018-02-26 00:25:40', 'sysadmin')") or die("Insertion query: " . mysqli_error());
											
											header("location: view/view-menu.html");
											exit;
										}	
									}
								}
                                ?>
                                <form method="post">
                                    <table class="table table-striped">
                                        <tbody>
                                            <tr>
                                                <th nowrap="nowrap" scope="row"><label for="dbname">Database Name</label></th>
                                              <td><input name="dbname" id="dbname" type="text" size="25" class="form-control" value="documentation"></td>
                                                <td>The name of the database that you want to use.</td>
                                            </tr>
                                            <tr>
                                                <th scope="row"><label for="uname">Username</label></th>
                                                <td><input name="uname" id="uname" type="text" size="25" class="form-control" value="root"></td>
                                                <td>Your database username.</td>
                                            </tr>
                                            <tr>
                                                <th scope="row"><label for="pwd">Password</label></th>
                                                <td><input name="pwd" id="pwd" type="text" size="25" class="form-control" value="" autocomplete="off"></td>
                                                <td>Your database password.</td>
                                            </tr>
                                            <tr>
                                                <th scope="row"><label for="dbhost">Database Host</label></th>
                                                <td><input name="dbhost" id="dbhost" type="text" size="25" class="form-control" value="localhost"></td>
                                                <td>You should be able to get this info from your web host, if <code>localhost</code> doesn’t work.</td>
                                            </tr>
                                            <tr>
                                                <th scope="row"><label for="dbhost">Table Name</label></th>
                                                <td><input name="tbname" id="tbname" type="text" size="25" class="form-control" value="tb_help_menu"></td>
                                                <td>You should be able to get this info from your web host, if <code>localhost</code> doesn’t work.</td>
                                            </tr>
                                            <tr>
                                                <td><input type="submit" name="create" class="btn btn-default" value="Create"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div> <!-- /.row -->
                    </div> <!-- ./box-body -->
                </div>
                <?php } ?>
            </div>
        </div>
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->
    
</div> <!-- ./wrapper -->

<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="custom/js/app.js"></script>

</body>
</html>
