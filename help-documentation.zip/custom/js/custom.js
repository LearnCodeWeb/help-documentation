$(document).ready(function(e) {
	
	var SS_URL	=	document.location.origin;	
	
	//datepicker
	$('.datepicker').datepicker({
		format: "yyyy-mm-dd",
		clearBtn: true,
		autoclose: true,
		todayHighlight: true,
		toggleActive: true,
	});
	
	//yearpicker
	$('.yearpicker').datepicker({
		format: "yyyy",
		clearBtn: true,
		autoclose: true,
		todayHighlight: true,
		toggleActive: true,
		viewMode: "years", 
		minViewMode: "years"
	});
	
	//Browse file code
	var file = $(this).parent().parent().parent().find('.file');
  	file.trigger('click');
  	$(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
	
	//Tooltip
	$('[data-toggle="tooltip"]').tooltip();
	
	//Colorbox
	$('.ajax').colorbox();
	$('.iframe').colorbox({iframe:true, width:'90%', maxWidth:'1400px', height:'100%', overlayClose:false, fixed:true,});
	
	
	//Editor
	/*$('.editorBox').summernote({
		height: 510,
		tabsize: 2,
	});*/
	
	//Select picker
	$('.selectpicker').selectpicker({
		size: 15,
	});
	
	tinymce.init({
		selector:'textarea.editorBox',
		height: 510,
		menubar:false,
		subfolder:"",
		plugins: [
		  "advlist autolink lists link image charmap print preview anchor",
		  "searchreplace visualblocks code fullscreen",
		  "insertdatetime media table contextmenu paste textcolor filemanager hr codesample"
		],
		toolbar: "insertfile undo redo | hr | formatselect | bold italic underline fontsizeselect | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table | forecolor backcolor | unlink link image media | print preview code codesample",
		contextmenu: "link inserttable | cell row column deletetable",
		// ===========================================
		// SET RELATIVE_URLS to FALSE (This is required for images to display properly)
		// ===========================================
		relative_urls: false,
		image_advtab: true,
		fontsize_formats: '8px 10px 12px 14px 18px 24px 36px',
	});
	
	$(window).load(function(){
		$("#content-in").fadeIn('slow');
	});
	
	
	/*$('ul.sidebar-menu > li').find('a').each(function () {
		$(this).on("click",function(){
			if (document.location.href == $(this).attr('data-url')) {
				$(this).parents('.sidebar-menu').find('li.active').removeClass("active");
				$(this).parents('li').addClass("active");
			}
		});
	});*/
	
	
	$('.openPopup').on('click',function(){
        var dataURL = $(this).attr('data-href');
        $('.modal-body').load(dataURL,function(){
            $('#searchModal').modal({show:true});
        });
    });
	$('#searchModal').on('hidden.bs.modal', function () {
		$(this).find('.box').remove();
	})
	
	
	$('.openMenuPopup').on('click',function(){
        var dataURL = $(this).attr('data-href');
        $('.modal-body').load(dataURL,function(){
            setTimeout(function(){
				$('#myModal').modal({
					show:true,
				});
			},500);
        });
    });
	
	$("#mark-parent-btn").on("click",function(){
		$(this).toggleClass('btn-success');
		if($(this).hasClass('btn-success')){
			$("#markParent").val('0');
		}else{
			$("#markParent").val('1');
		}
	});
	
	//Image overlay
	$ovr	=	$('#overlay');
	$('img').click(function(){
		$('body').css({'overflow':'hidden'});
		$ovr.fadeTo(100,1).html('<div class="vertical-center"><img src="'+this.src+'"></div>');
	});
	$ovr.click(function(){
		$(this).stop().fadeTo(100,0,function(){
			$('body').removeAttr('style');
			$(this).hide();
			$(this).find('div').remove();
		});
	});  
	
	$("#menuOrder").on("click",function(){
		$("html, body").animate({ scrollTop: 0 }, 200);
		
		$(".sorting").sortable({ tolerance: 'pointer' });
		
		$("#reordingMsg").html('<div class="callout callout-warning"><h4><i class="fa fa-fw fa-exclamation-triangle"></i> Reordering start now!</h4><p>You can reorder the menu as per your need! After reordering click on <strong>Save Reordering</strong> button to save reordered menu.</p></div>');
		$(this).addClass('btn-danger');
		$(this).removeClass('btn-primary');
		$(this).html('Cancel Reordering');
		$(this).removeAttr('id');
		$(this).attr('id','cancelReorder');
		$("#saveReorder").removeClass('hidden');
		$("#cancelReorder").on("click",function(){
			$("html, body").animate({ scrollTop: 0 }, 200);
			setTimeout(function(){	location.reload(); },500);
		});
	});
	
});

function goBack() {
    window.history.back();
}

var newName = 	'';
function changeTitle(newName){
	document.title	=	'';
	var newTitle 	= 	newName;
   	document.title 	= 	newTitle;
}
