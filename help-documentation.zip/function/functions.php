<?php
function createMenu($arr,$urutan,$requestID){
	if(isset($_REQUEST['v']) and $_REQUEST['v']=="view-menu"){$ac	= 	' active';}else{$ac	= 	'';}
	if($urutan==0){
		$html = "\n<ul class='sidebar-menu'><li class='treeview".$ac."'><a href='".SS_URL."view/view-menu.html'><i class='fa fa-fw fa-list'></i> <span>View Menu</span></a></li>\n";
	}else{
		$html = "\n<ul class='treeview-menu'>\n";
	}
	foreach($arr as $key=>$v){
		if(array_key_exists('children', $v)){
			$id   	=	explode("/",$v['url']);
			if($requestID==$id[1]){$cn	= 	' active';}else{$cn	= 	'';}
			$html .= "<li class='treeview".$cn."'>\n";
			?>
            <script>$(document).ready(function(e) {menuCall('<?php echo $id[1]; ?>','<?php echo $v['url']; ?>','<?php echo getMenuTitle($id[1]); ?>','#overlayContent','<?php echo SS_URL; ?>');});</script>
            <?php
			$html .= '<a href="#" data-url="'.SS_URL.$v['url'].'" id="'.$id[1].'">
						<i class="fa fa-fw fa-circle-o"></i>
						<span>'.$v['menu_item_name'].'</span>
						<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
					  </a>';
			$html .= createMenu($v['children'],1,$requestID);
			$html .= "</li>\n";
		}else{
			$id   	=	explode("/",$v['url']);
			if($requestID==$id[1]){$cn	= 	'active';}else{$cn	= 	'';}
			?>
            <script>$(document).ready(function(e) {menuCall('<?php echo $id[1]; ?>','<?php echo $v['url']; ?>','<?php echo getMenuTitle($id[1]); ?>','#overlayContent','<?php echo SS_URL; ?>');});</script>
            <?php
			$html .= '<li class="'.$cn.'"><a href="javascript:void(0);" data-url="'.SS_URL.$v['url'].'" id="'.$id[1].'">';
			if($urutan==0){
				$html .=	'<i class="fa fa-fw fa-circle-o"></i>';
			}if($urutan==1){
				$html .=	'<i class="fa fa-angle-double-right"></i>';
			}
			$html .= "<span>".$v['menu_item_name']."</span></a></li>\n";
		}
	}
	$html .= "</ul>\n";
	return $html;
}

function viewMenu($list,$reqEditID){
	foreach($list as $menu){
		if($reqEditID==$menu['id']){$select	= 'selected';}else{$select	=	'';}
		echo "<li ".$select."><a href=''>".$menu['title']."</a>";
		if(array_key_exists('children', $menu)){
			echo "<ul class='child-nav'>";
			viewMenu($menu['children'],$reqEditID);
			echo "</ul>";
		}
		echo '</li>';
	}
}

function viewMenuOption($list,$reqEditID){
	
	foreach($list as $menu){
		$select	=	$parent		= 	'';
		if($reqEditID==$menu['id']){$select	= 'selected';}else{$select	=	'';}
		
		//Without option group
		if(!empty($list[$menu['id']]['children'])){
			$parent	= 'data-subtext="<em class=parent>Parent</em>"';
		}else{
			$parent	= '';
		}
		echo '<option value="'.$menu['id'].'" '.$select.' '.$parent.' >'.stripslashes($menu['title']).'';
        if(array_key_exists('children', $menu)){
			viewMenuOption($menu['children'],$reqEditID);
		}
		echo '</option>';
	}
}

function listMenu($list){
	foreach($list as $row){
		echo '<li class="list-group-item d-flex justify-content-between align-items-center margin-left" id="menuP'.$row['id'].'">';
		?>
        <script>
			$(document).ready(function(e) {
				$("#delID<?php echo $row['id']; ?>").on("click",function(){
					if(confirm("Are you sure to delete this menu?")){
						$.ajax({
							url:'<?php echo SS_URL; ?>ajax/action-form.php',
							data:{'delID':'<?php echo $row['id']; ?>'},
							success: function(data){
								if(data==1 || parseInt(data)==1){
									$("#delID<?php echo $row['id']; ?>").parents('#menuP<?php echo $row['id']; ?>').remove();
								}
							}
						});
					}
				});
			});
		</script>
        <?php
		$class	=	'';
		if(!empty($list[$row['id']]['children'])){$class	=	"a-disable";}else{$class	=	"";}
			echo '<span id="hide'.$row['id'].'"><i class="fa fa-fw fa-angle-double-right"></i> <span>'.stripslashes($row['title']).'</span></span>';
			echo '<span class="pull-right">';
			echo '<a href="'.SS_URL.$row['url'].'" class="text-warning" data-toggle="tooltip" title="View"><i class="fa fa-fw fa-external-link"></i></a>';
			echo '<a href="'.SS_URL.'edit/'.$row['id'].'/menu-edit.html" class="text-primary"><i class="fa fa-fw fa-pencil"></i></a> ';
			if(empty($list[$row['id']]['children'])){echo '<a href="javascript:void(0);" id="delID'.$row['id'].'" class="text-danger btn-xs '.$class.'"><i class="fa fa-fw fa-trash"></i></a>';}
			echo '</span>';
			
			if(array_key_exists('children', $row)){
				echo '<ul class="list-group nested-level">';
				listMenu($row['children']);
				echo '</ul>';
			}
		echo '</li>';
	}
}

function clean($string){
   $string = trim(str_replace(' ', '-', trim($string))); // Replaces all spaces with hyphens.
   return preg_replace('/[^\w\s]+/u','' , strtolower($string)); // Replaces multiple hyphens with single one.
}

function checkParentIds($id,$pIdArr 	= 	array()){
	global $db;
	$row 	= 	$db->getAllRecords(SS_TB_NAME,'id,parent_id'," AND id = '".$id."'");
	if($row[0]['parent_id'] > 0){
		checkParentIds($row[0]['parent_id']);
		print $row[0]['parent_id'].',';
	}
}

function getAllChildId($id){
	global $db;
	$row 	= 	$db->getAllRecords(SS_TB_NAME,'id,parent_id'," AND id = '".$id."'");
	if($row[0]['parent_id'] > 0){
		checkParentIds($row[0]['parent_id']);
		print $row[0]['parent_id'].',';
	}
}

function getMenuTitle($id){
	global $db;
	$row 	= 	$db->getAllRecords(SS_TB_NAME,'title'," AND id = '".$id."'");
	if(!empty($row[0]['title'])){
		return ($row[0]['title']);
	}
}

function createPath($id, $category_tbl){
	global $db;
	$active	=	'';
	if(isset($_REQUEST['id']) and $_REQUEST['id']==$id){$active	=	'active';}
    $row	= 	$db->getAllRecords($category_tbl,"*"," AND id = '".$id."'");
	if($row[0]['parent_id'] == 0) {
        return '<li class="breadcrumb-item '.$active.'"><a href="'.SS_URL.$row[0]['url'].'">'.$row[0]['title'].'</a></li>';
    } else {
		return createPath($row[0]['parent_id'],$category_tbl).'<li class="breadcrumb-item '.$active.'"><a href="'.SS_URL.$row[0]['url'].'">'.$row[0]['title'].'</a></li>';
    }
}

function header_redirect_permanent($url){
	header($_SERVER['SERVER_PROTOCOL'] . ' 301 Moved Permanently', true, 301);
	header('Location: ' . $url);
}
function header_redirect($url){
	header('Location: ' . $url);
}

function header_no_cache(){
	header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
	header('Expires: Sat, 26 Jul 1997 05:00:00 GMT'); // past date to encourage expiring immediately
}