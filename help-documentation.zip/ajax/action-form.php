<?php require('../config/config.php');
if(isset($_REQUEST['createPage']) and $_REQUEST['createPage']!=""){
	extract($_REQUEST);
	
	$menuOrder		=	0;
	
	$pID	=	'';
	if(isset($parent_id) and $parent_id!=""){
		$pID	=	$parent_id;
	}
	if(isset($subMenu1) and $subMenu1!=""){
		$pID	=	$subMenu1;
	}
	if(isset($subMenu2) and $subMenu2!=""){
		$pID	=	$subMenu2;
	}
	if(isset($subMenu3) and $subMenu3!=""){
		$pID	=	$subMenu3;
	}
	if(isset($subMenu4) and $subMenu4!=""){
		$pID	=	$subMenu4;
	}
	if(isset($subMenu5) and $subMenu5!=""){
		$pID	=	$subMenu5;
	}
	if(isset($subMenu6) and $subMenu6!=""){
		$pID	=	$subMenu6;
	}
	
	if($pID==0){
		$getMaxOrder	=	$db->getAllRecords(SS_TB_NAME,'max(menu_order) as menuOrder');
		$menuOrder		=	$getMaxOrder[0]['menuOrder']+1;
	}
	
	
	$newTitle	=	clean($title);
	$data		=	array(
					'parent_id'=>$pID,
					'title'=>addslashes(trim($title)),
					'status'=>1,
					'menu_order'=>$menuOrder,
					'description'=>htmlentities(addslashes($description)),
					'user'=>'zaid',
					);
	$db->insert(SS_TB_NAME,$data);
	$lastId		=	$db->lastInsertId();
	$updateData	=	array(
						'url'=>'page/'.$lastId.'/'.$newTitle.'.html',
						);
	$up			=	$db->update(SS_TB_NAME,$updateData,array('id'=>$lastId));
	
	if($up){
		echo '<div class="callout callout-success"><p><i class="fa fa-fw fa-thumbs-up"></i> Record save successfully <strong>Please Wait...</strong></p></div>|***|1';
	}else{
		echo '<div class="callout callout-danger"><p><i class="fa fa-fw fa-exclamation-triangle"></i> There is some thing wrong <strong>Please Wait...</strong></p></div>|***|0';
	}
}

//Menu update
if(isset($_REQUEST['editID']) and $_REQUEST['editID']!=""){
	extract($_REQUEST);
	//Remove non language chracters
	#$newTitle	=	preg_replace('/[^\p{L}\p{M}\p{Z}\p{N}\p{P}]/u', ' ', $title);
	
	$newTitle	=	clean($title);
	$getPId		=	$db->getAllRecords(SS_TB_NAME,'parent_id','AND id="'.$_REQUEST['editID'].'"');
	$pID		=	($markParent==1)?$getPId[0]['parent_id']:$markParent;
	
	if(isset($parent_id) and $parent_id!=""){
		$pID	=	$parent_id;
	}
	if(isset($subMenu1) and $subMenu1!=""){
		$pID	=	$subMenu1;
	}
	if(isset($subMenu2) and $subMenu2!=""){
		$pID	=	$subMenu2;
	}
	if(isset($subMenu3) and $subMenu3!=""){
		$pID	=	$subMenu3;
	}
	if(isset($subMenu4) and $subMenu4!=""){
		$pID	=	$subMenu4;
	}
	if(isset($subMenu5) and $subMenu5!=""){
		$pID	=	$subMenu5;
	}
	if(isset($subMenu6) and $subMenu6!=""){
		$pID	=	$subMenu6;
	}
	
	if($pID==$_REQUEST['editID']){
		echo '<div class="callout callout-danger"><p><i class="fa fa-fw fa-exclamation-triangle"></i> Same menu you try to make a parent menu! </p></div>|***|0';
		exit;
	}


	$data	=	array(
					'parent_id'=>$pID,
					'title'=>addslashes(trim($title)),
					'status'=>1,
					'description'=>htmlentities(addslashes($description)),
					'user'=>'zaid',
					);
	$db->update(SS_TB_NAME,$data,array('id'=>$editID));
	//URL UPDATE TOO
	$updateData	=	array(
						'url'=>'page/'.$editID.'/'.$newTitle.'.html',
						);
	$db->update(SS_TB_NAME,$updateData,array('id'=>$editID));
	echo '<div class="callout callout-success"><p><i class="fa fa-fw fa-thumbs-up"></i> Record update successfully <strong>Please Wait...</strong></p></div>|***|1';
}

//Parent menu name update
if(isset($_REQUEST['updateID']) and $_REQUEST['updateID']!=""){
	extract($_REQUEST);
	$newTitle	=	clean($updatedName);
	$data	=	array(
					'title'=>addslashes(trim($updatedName)),
					'user'=>'zaid',
					);
	$update	=	$db->update(SS_TB_NAME,$data,array('id'=>$updateID));
	if($update){
		//URL UPDATE TOO
		$updateData	=	array(
							'url'=>'page/'.$updateID.'/'.$newTitle.'.html',
							);
		$db->update(SS_TB_NAME,$updateData,array('id'=>$updateID));
		echo trim($updatedName).'|***|1';
	}else{
		echo '|***|0';
	}
}

//Menu delete
if(isset($_REQUEST['delID']) and $_REQUEST['delID']!=""){
	$del	=	$db->delete(SS_TB_NAME,array('id'=>$_REQUEST['delID']));
	if($del){
		echo 1;
	}else{
		echo 0;
	}
}

//First child
if(isset($_REQUEST['menuReq0']) and $_REQUEST['menuReq0']!=""){
	extract($_REQUEST);
	$cond	=	$disabled	=	'';
	if(isset($mEditId) and $mEditId!=""){
		//$cond		.=	' AND id<>"'.$mEditId.'" ';
		$disabled	=	'disabled';
	}
	$menu	=	$db->getAllRecords(SS_TB_NAME,'*',' AND parent_id="'.$menuReq0.'" '.$cond.' ');
	if(count($menu)>0){
	?>
	<script> $(document).ready(function(){ getMenuChild("#parent2<?php echo $menuReq0; ?>","#showMenu1","menuReq1","<?php echo isset($mEditId)?$mEditId:''; ?>"); $(".selectpicker").selectpicker("refresh"); });</script>
    <div class="col-sm-6"><div class="form-group"><label>First Level</label><select name="subMenu1" id="parent2<?php echo $menuReq0;?>" data-live-search="true" class="form-control selectpicker" data-size="15"><option value="">Please select</option>
    <?php
        foreach($menu as $val){
            ?>
            <option value="<?php echo $val['id']; ?>" <?php if(isset($mEditId) and $val['id']==$mEditId){echo $disabled.' data-subtext="<i class=parent>Disabled</i>"';} ?> ><?php echo stripslashes($val['title']); ?></option>
            <?php
        }
        echo '</select></div></div><div id="showMenu1"></div>|***|1';
    }else{
        echo '|***|0';
    }
}

//Second menu child
if(isset($_REQUEST['menuReq1']) and $_REQUEST['menuReq1']!=""){
	extract($_REQUEST);
	$cond	=	$disabled	=	'';
	if(isset($mEditId) and $mEditId!=""){
		 //$cond	.=	' AND id<>"'.$mEditId.'" ';
		 $disabled	=	'disabled';
	}
	$menu	=	$db->getAllRecords(SS_TB_NAME,'*',' AND parent_id="'.$menuReq1.'" '.$cond.' ');
	if(count($menu)>0){
	?>
	<script> $(document).ready(function(){ getMenuChild("#parent3<?php echo $menuReq1;?>","#showMenu2","menuReq2","<?php echo isset($mEditId)?$mEditId:''; ?>"); $(".selectpicker").selectpicker("refresh"); });</script>
    <div class="col-sm-6"><div class="form-group"><label>Second Level</label><select name="subMenu2" id="parent3<?php echo $menuReq1;?>" data-live-search="true" class="form-control selectpicker" data-size="15"><option value="">Please select</option>
    <?php
        foreach($menu as $val){
            ?>
            <option value="<?php echo $val['id']; ?>" <?php if(isset($mEditId) and $val['id']==$mEditId){echo $disabled.' data-subtext="<i class=parent>Disabled</i>"';} ?> ><?php echo stripslashes($val['title']); ?></option>
            <?php
        }
        echo '</select></div></div><div id="showMenu2"></div></div>|***|1';
    }else{
        echo '|***|0';
    }
}

//Third menu child
if(isset($_REQUEST['menuReq2']) and $_REQUEST['menuReq2']!=""){
	extract($_REQUEST);
	$cond	=	$disabled	=	'';
	if(isset($mEditId) and $mEditId!=""){
		 //$cond	.=	' AND id<>"'.$mEditId.'" ';
		 $disabled	=	'disabled';
	}
	$menu	=	$db->getAllRecords(SS_TB_NAME,'*',' AND parent_id="'.$menuReq2.'" '.$cond.' ');
	if(count($menu)>0){
	?>
	<script> $(document).ready(function(){ getMenuChild("#parent4<?php echo $menuReq2;?>","#showMenu3","menuReq3","<?php echo isset($mEditId)?$mEditId:''; ?>"); $(".selectpicker").selectpicker("refresh"); });</script>
    <div class="col-sm-6"><div class="form-group"><label>Third Level</label><select name="subMenu3" id="parent4<?php echo $menuReq2;?>" data-live-search="true" class="form-control selectpicker" data-size="15"><option value="">Please select</option>
    <?php
        foreach($menu as $val){
            ?>
            <option value="<?php echo $val['id']; ?>" <?php if(isset($mEditId) and $val['id']==$mEditId){echo $disabled.' data-subtext="<i class=parent>Disabled</i>"';} ?> ><?php echo stripslashes($val['title']); ?></option>
            <?php
        }
        echo '</select></div></div><div id="showMenu3"></div></div>|***|1';
    }else{
        echo '|***|0';
    }
}



//fourth menu child
if(isset($_REQUEST['menuReq3']) and $_REQUEST['menuReq3']!=""){
	extract($_REQUEST);
	$cond	=	$disabled	=	'';
	if(isset($mEditId) and $mEditId!=""){
		 //$cond	.=	' AND id<>"'.$mEditId.'" ';
		 $disabled	=	'disabled';
	}
	$menu	=	$db->getAllRecords(SS_TB_NAME,'*',' AND parent_id="'.$menuReq3.'" '.$cond.' ');
	if(count($menu)>0){
	?>
	<script> $(document).ready(function(){ getMenuChild("#parent5<?php echo $menuReq3;?>","#showMenu4","menuReq4","<?php echo isset($mEditId)?$mEditId:''; ?>"); $(".selectpicker").selectpicker("refresh"); });</script>
    <div class="col-sm-6"><div class="form-group"><label>Fourth Level</label><select name="subMenu4" id="parent5<?php echo $menuReq3;?>" data-live-search="true" class="form-control selectpicker" data-size="15"><option value="">Please select</option>
    <?php
        foreach($menu as $val){
            ?>
            <option value="<?php echo $val['id']; ?>" <?php if(isset($mEditId) and $val['id']==$mEditId){echo $disabled.' data-subtext="<i class=parent>Disabled</i>"';} ?> ><?php echo stripslashes($val['title']); ?></option>
            <?php
        }
        echo '</select></div></div><div id="showMenu4"></div></div>|***|1';
    }else{
        echo '|***|0';
    }
}

//fifth menu child
if(isset($_REQUEST['menuReq4']) and $_REQUEST['menuReq4']!=""){
	extract($_REQUEST);
	$cond	=	$disabled	=	'';
	if(isset($mEditId) and $mEditId!=""){
		 //$cond	.=	' AND id<>"'.$mEditId.'" ';
		 $disabled	=	'disabled';
	}
	$menu	=	$db->getAllRecords(SS_TB_NAME,'*',' AND parent_id="'.$menuReq4.'" '.$cond.' ');
	if(count($menu)>0){
	?>
	<script> $(document).ready(function(){ getMenuChild("#parent6<?php echo $menuReq4;?>","#showMenu5","menuReq5","<?php echo isset($mEditId)?$mEditId:''; ?>"); $(".selectpicker").selectpicker("refresh");});</script>
    <div class="col-sm-6"><div class="form-group"><label>Fifth Level</label><select name="subMenu5" id="parent6<?php echo $menuReq4;?>" data-live-search="true" class="form-control selectpicker" data-size="15"><option value="">Please select</option>
    <?php
        foreach($menu as $val){
            ?>
            <option value="<?php echo $val['id']; ?>" <?php if(isset($mEditId) and $val['id']==$mEditId){echo $disabled.' data-subtext="<i class=parent>Disabled</i>"';} ?> ><?php echo stripslashes($val['title']); ?></option>
            <?php
        }
        echo '</select></div></div><div id="showMenu5"></div></div>|***|1';
    }else{
        echo '|***|0';
    }
}


//six menu child
if(isset($_REQUEST['menuReq5']) and $_REQUEST['menuReq5']!=""){
	extract($_REQUEST);
	$cond	=	$disabled	=	'';
	if(isset($mEditId) and $mEditId!=""){
		 //$cond	.=	' AND id<>"'.$mEditId.'" ';
		 $disabled	=	'disabled';
	}
	$menu	=	$db->getAllRecords(SS_TB_NAME,'*',' AND parent_id="'.$menuReq5.'" '.$cond.' ');
	if(count($menu)>0){
	?>
	<script> $(document).ready(function(){ getMenuChild("#parent7<?php echo $menuReq5;?>","#showMenu6","menuReq6","<?php echo isset($mEditId)?$mEditId:''; ?>"); $(".selectpicker").selectpicker("refresh"); });</script>
    <div class="col-sm-6"><div class="form-group"><label>Sixth Level</label><select name="subMenu6" id="parent7<?php echo $menuReq5;?>" data-live-search="true" class="form-control selectpicker" data-size="15"><option value="">Please select</option>
    <?php
        foreach($menu as $val){
            ?>
            <option value="<?php echo $val['id']; ?>" <?php if(isset($mEditId) and $val['id']==$mEditId){echo $disabled.' data-subtext="<i class=parent>Disabled</i>"';} ?> ><?php echo stripslashes($val['title']); ?></option>
            <?php
        }
        echo '</select></div></div><div id="showMenu6"></div></div>|***|1';
    }else{
        echo '|***|0';
    }
}


if(isset($_REQUEST['ajax']) and $_REQUEST['ajax']=="content"){
    if(isset($_REQUEST['id']) and $_REQUEST['id']!=""){
        $mainID	=	isset($_REQUEST['id'])?$_REQUEST['id']:'';
        $row	=	$db->getAllRecords(SS_TB_NAME,'*',' AND id="'.$mainID.'"');
        echo '<ol class="breadcrumb breadcrumb-fix">';
        echo createPath($row[0]['id'], SS_TB_NAME);
        echo '</ol>';
    }
    ?>
    <div class="box box-primary">
        <div id="overlay"></div>
        <script type="text/javascript">
            $(document).ready(function(e) {
                //Image overlay
                $ovr	=	$('#overlay');
                $('img').click(function(){
                    $('body').css({'overflow':'hidden'});
                    $ovr.fadeTo(100,1).html('<div class="vertical-center"><img src="'+this.src+'"></div>');
                });
                $ovr.click(function(){
                    $(this).stop().fadeTo(100,0,function(){
                        $('body').removeAttr('style');
                        $(this).hide();
                        $(this).find('div').remove();
                    });
                });
                
                $("#find-img").find('img').each(function(index, element) {
                    $(this).addClass('img-responsive img-thumbnail');
                });
                
                //Create clone
                $("#clone_<?php echo $row[0]['id']; ?>").on("click",function(){
                    $.ajax({
                        type:'POST',
                        url:'<?php echo SS_URL; ?>ajax/action-form.php',
                        data:{'clone':'ok','id':'<?php echo $row[0]['id']; ?>'},
                        success: function(data){
                            a	=	data.split('|***|');
                            if(a[1]==1){
                                window.location.href=a[0];
                            }else{
                                $("#clone-msg").html(a[0]);
                            }
                        }
                    });
                });
            });
        </script>
        <div class="box-header with-border">
            <h3 class="box-title"><i class="fa fa-fw fa-file"></i> <?php echo isset($row[0]['title'])?$row[0]['title']:''; ?></h3>
            <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Hide/Show"><i class="fa fa-minus"></i></button>
                
                <a href="<?php echo SS_URL.'edit/'.$row[0]['id'].'/menu-edit.html'; ?>" class="btn btn-box-tool" data-toggle="tooltip" title="Edit"><i class="fa fa-fw fa-pencil"></i></a>
                <a href="javascript:void(0);" id="clone_<?php echo $row[0]['id']; ?>" class="btn btn-box-tool" data-toggle="tooltip" title="Clone"><i class="fa fa-fw fa-clone"></i></a>
            </div>
        </div> <!-- /.box-header -->
        <div class="box-body">
            <div class="row">
                <div class="col-sm-12" id="find-img">
                    <?php echo isset($row[0]['description'])?html_entity_decode(stripslashes($row[0]['description'])):''; ?>
                </div>
            </div> <!-- /.row -->
        </div> <!-- ./box-body -->
        <div class="box-footer">
            <div class="row">
                <div class="col-sm-12 col-xs-12 text-right">
                    <h5 class="description-header"><i class="fa fa-fw fa-user"></i> <?php echo isset($row[0]['user'])?ucfirst($row[0]['user']):''; ?></h5>
                    <span class="description-text"><i class="fa fa-fw fa-clock-o"></i> <?php echo isset($row[0]['dt'])?$row[0]['dt']:''; ?></span>
                </div> <!-- /.col -->
            </div> <!-- /.row -->
        </div> <!-- /.box-footer -->
    </div> <!-- /.box -->
<?php
}

if(isset($_REQUEST['ajax']) and $_REQUEST['ajax']=="popup"){
	if(isset($_REQUEST['id']) and $_REQUEST['id']!=""){
		$mainID	=	isset($_REQUEST['id'])?$_REQUEST['id']:'';
		$row	=	$db->getAllRecords(SS_TB_NAME,'*',' AND id="'.$mainID.'"');
		echo '<ol class="breadcrumb breadcrumb-fix">';
		echo createPath($row[0]['id'], SS_TB_NAME);
		echo '</ol>';
	}
	?>
    <div class="box box-primary">
        <div id="overlay"></div>
        <script type="text/javascript">
			$(document).ready(function(e) {
				$("#find-img").find('img').each(function(index, element) {
					$(this).addClass('img-responsive img-thumbnail');
				});
			});
		</script>
        <div class="box-header with-border">
            <h3 class="box-title"><i class="fa fa-fw fa-file"></i> <?php echo isset($row[0]['title'])?$row[0]['title']:''; ?></h3>
            <div class="box-tools pull-right">
            	<a href="<?php echo SS_URL.$row[0]['url']; ?>" class="btn btn-warning btn-sm"><i class="fa fa-fw fa-share"></i> Open Page</a>
            </div>
        </div> <!-- /.box-header -->
        <div class="box-body">
            <div class="row">
                <div class="col-sm-12" id="find-img">
                    <?php echo isset($row[0]['description'])?html_entity_decode(stripslashes($row[0]['description'])):''; ?>
                </div>
            </div> <!-- /.row -->
        </div> <!-- ./box-body -->
        <div class="box-footer">
            <div class="row">
                <div class="col-sm-12 col-xs-12 text-right">
                    <h5 class="description-header"><i class="fa fa-fw fa-user"></i> <?php echo isset($row[0]['user'])?ucfirst($row[0]['user']):''; ?></h5>
                    <span class="description-text"><i class="fa fa-fw fa-clock-o"></i> <?php echo isset($row[0]['dt'])?$row[0]['dt']:''; ?></span>
                </div> <!-- /.col -->
            </div> <!-- /.row -->
        </div> <!-- /.box-footer -->
    </div> <!-- /.box -->
    <?php
}


//Create clone
if(isset($_REQUEST['clone']) and $_REQUEST['clone']=="ok"){
	global $db;
	extract($_REQUEST);
	$cloneData	=	$db->getAllRecords(SS_TB_NAME,'*',' AND id="'.$id.'"');
	$newTitle	=	clean($cloneData[0]['title'].' Copy');
	$data		=	array(
						'parent_id'=>$cloneData[0]['parent_id'],
						'title'=>$cloneData[0]['title'].' Copy',
						'status'=>$cloneData[0]['status'],
						'icon'=>$cloneData[0]['icon'],
						'description'=>$cloneData[0]['description'],
						'user'=>'zaid',
						);
	$db->insert(SS_TB_NAME,$data);
	$lastId		=	$db->lastInsertId();
	$updateData	=	array(
						'url'=>'page/'.$lastId.'/'.$newTitle.'.html',
						);
	$up			=	$db->update(SS_TB_NAME,$updateData,array('id'=>$lastId));
	if($up){
		echo SS_URL.'edit/'.$lastId.'/menu-edit.html|***|1';
	}else{
		echo '<div class="callout callout-danger"><p><i class="fa fa-fw fa-exclamation-triangle"></i> There is some thing wrong <strong>Please Wait...</strong></p></div>|***|0';
	}
}


if(isset($_REQUEST['reorder']) and $_REQUEST['reorder']=="ok"){
	extract($_REQUEST);
	$allSortIds		=	explode(",",$ids);
	$count = 1;
	foreach ($allSortIds as $id){
		$data	=	array(
						'menu_order'=>$count,
					);
		$update = $db->update(SS_TB_NAME,$data,array('id'=>$id));
		$count ++;	
	}
	echo '<div class="callout callout-success"><p><i class="fa fa-fw fa-thumbs-up"></i> Menu order changed successfully <strong>Please Wait...</strong></p></div>|***|1';
}