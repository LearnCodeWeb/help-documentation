<!-- Content Header (Page header) -->
<section class="content-header">
  	<h1 class="pull-left"> AZCW System Help </h1>
  		<div class="pull-right hidden-xs btn-group">
			<a href="<?php echo SS_URL.'menu/create-menu.html'; ?>" class="btn btn-primary"><i class="fa fa-fw fa-plus-circle"></i> Create Menu</a>
        </div>
  <div class="clearfix"></div>
</section>