<?php include_once('header.php'); ?>
<div class="wrapper">
	<!-- /.navbar -->
    <?php include_once('top-bar.php'); ?>
  	<!-- Left side column. contains the logo and sidebar -->
    <?php if(file_exists('config/database.php')){include_once('side-bar.php');} ?>
	
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper c-w" id="content-in">
	<?php include_once('title-bar.php'); ?>
	<section class="content">
        <div class="row">
        	<div class="col-sm-12">
            	<div id="overlayContent"><i class="fa fa-fw fa-spin fa-spinner"></i> Please wait...!</div>
                <div id="showContent"></div>
                <div id="menuPage">
                <div id="reordingMsg"></div>
                <script>
					$(document).ready(function(e) {
                        $("#sorting").on("submit",function(){
							$("html, body").animate({ scrollTop: 0 }, 200);
							$(".sorting").sortable('destroy');
							var h = [];
							$(".sorting > div").each(function() { h.push($(this).attr('sort-id')); });
							$("#overlayContent").show();
							$.ajax({
								type:'POST',
								url:'<?php echo SS_URL; ?>ajax/menu-order/action-form.html',
								data:{'ids':''+h+'','reorder':'ok'},
								success: function(data){
									a	=	data.split('|***|');
									if(a[1]==1){
										$("#overlayContent").hide();
										$("#reordingMsg").html(a[0]);
										setTimeout(function(){location.reload()},1500);
									}
								}
							});
						});
                    });
				</script>
                <form method="post" id="sorting" onSubmit="return false;">
                <?php
					$sql	=	$db->getRecFrmQry('SELECT id,parent_id,title,menu_order,url FROM '.SS_TB_NAME.' ORDER BY menu_order,id ASC');
					$refs 	= array();
					$list 	= array();
					foreach($sql as $data){
						$thisref 	= 	&$refs[$data['id']];
						$thisref['id'] 			= 	$data['id'];
						$thisref['parent_id'] 	= 	$data['parent_id'];
						$thisref['title'] 		= 	$data['title'];
						$thisref['url'] 		= 	$data['url'];
						$thisref['menu_order']	= 	$data['menu_order'];
						if($data['parent_id'] == 0){
							$list[$data['id']] 	= 	&$thisref;
						}else{
							$refs[$data['parent_id']]['children'][$data['id']] = &$thisref;
						}
					}
					?>
                    <div class="sorting row">
					<?php if(count($list)>0){
						foreach($list as $key=>$val){ ?>
							<script>
                                $(document).ready(function(e) {
                                    //parent edit
                                    $("#parentEdit<?php echo $val['id']; ?>").on("click",function(){
                                        $("#hide<?php echo $val['id']; ?>, #parentEdit<?php echo $val['id']; ?>").hide();
                                        $("#show<?php echo $val['id']; ?>").show();
                                    });
                                    
                                    $("#cancel<?php echo $val['id']; ?>").on("click",function(){
                                        $("#hide<?php echo $val['id']; ?>, #parentEdit<?php echo $val['id']; ?>").show();
                                        $("#show<?php echo $val['id']; ?>").hide();
                                    });
                                });
                            </script>
                            <div class="col-sm-12 col-md-6 col-lg-6 getSortingId" id="menu-parent" sort-id="<?php echo $val['id']; ?>">
                                <div class="box box-primary collapsed-box">
                                    <div class="box-header with-border">
                                        <h3 id="hide<?php echo $val['id']; ?>" class="box-title"><span><?php echo $val['title'];  ?></span></h3>
                                        <div class="input-group" id="show<?php echo $val['id']; ?>" style="display:none;">
                                            <input type="text" class="form-control" name="parent_name" id="parent_name<?php echo $val['id']; ?>" value="<?php echo stripslashes($val['title']); ?>">
                                            <div class="input-group-btn">
                                                <script>
                                                    $(document).ready(function(e) {
                                                        $("#updateMenu<?php echo $val['id']; ?>").on("click",function(){
                                                            pname	=	$("#parent_name<?php echo $val['id']; ?>").val();
                                                            $.ajax({
                                                                type:'POST',
                                                                url:'<?php echo SS_URL; ?>ajax/action-form.php',
                                                                data:{'updateID':'<?php echo $val['id']; ?>','updatedName':pname},
                                                                success: function(data){
                                                                    a	=	data.split('|***|');
                                                                    if(a[1]==1){
                                                                        location.reload();
                                                                        $("#hide<?php echo $val['id']; ?>, #parentEdit<?php echo $val['id']; ?>").show();
                                                                        $("#show<?php echo $val['id']; ?>").hide();
                                                                        $("#hide<?php echo $val['id']; ?>").find('span').text(a[0]);
                                                                    }
                                                                }
                                                            });
                                                        });
                                                    });
                                                </script>
                                                <button type="button" class="btn btn-success" id="updateMenu<?php echo $val['id']; ?>"><i class="fa fa-fw fa-check"></i></button>
                                                <button type="button" class="btn btn-danger" id="cancel<?php echo $val['id']; ?>"><i class="fa fa-fw fa-times"></i></button>
                                            </div>
                                        </div>
                                        <div class="box-tools pull-right">
                                            <?php if(isset($_SESSION['access']['System_Help']) and $_SESSION['access']['System_Help']==1){ ?><a href="javascript:void(0);" id="parentEdit<?php echo $val['id']; ?>" class="text-danger"><i class="fa fa-fw fa-edit"></i></a><?php } ?>
                                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                        </div>
                                    </div> <!-- /.box-header -->
                                    <div class="box-body">
                                        <ul class="list-group">
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                <span><?php echo stripslashes($val['title']); ?></span>
                                                <span class="pull-right">
                                                    <a href="<?php echo SS_URL.$val['url']; ?>" class="text-warning" data-toggle="tooltip" title="View"><i class="fa fa-fw fa-eye"></i></a>
                                                    <a href="<?php echo SS_URL.'edit/'.$val['id'].'/menu-edit.html'; ?>" class="text-primary" data-toggle="tooltip" title="Edit"><i class="fa fa-fw fa-pencil"></i></a>
                                                    <?php if(isset($val['children']) and count($val['children'])>0){}else{?>
                                                    <script>
                                                        $(document).ready(function(e) {
                                                            $("#pDelID<?php echo $val['id']; ?>").on("click",function(){
                                                                if(confirm("Are you sure to delete this menu?")){
                                                                    $.ajax({
                                                                        url:'<?php echo SS_URL; ?>ajax/action-form.php',
                                                                        data:{'delID':'<?php echo $val['id']; ?>'},
                                                                        success: function(data){
                                                                            if(data==1 || parseInt(data)==1){
                                                                                $("#pDelID<?php echo $val['id']; ?>").parents('#menu-parent').remove();
                                                                            }
                                                                        }
                                                                    });
                                                                }
                                                            });
                                                        });
                                                    </script>
                                                    <a href="javascript:void(0);" id="pDelID<?php echo $val['id']; ?>" class="text-danger" data-toggle="tooltip" title="Delete"><i class="fa fa-fw fa-trash"></i></a>
                                                    <?php } ?>
                                                </span>
                                            </li>
                                            <?php if(!empty($val['children'])){ listMenu($val['children']); }  ?>
                                        </ul>
                                    </div> <!-- ./box-body -->
                                </div>
                            </div>
					<?php
						}
					}else{
					?>
					<div class="callout callout-danger">
						<h4><i class="fa fa-fw fa-exclamation-triangle"></i> Alert</h4>
						<p>There is nothing created yet. Please create menu first!</p>
					</div>
					<?php } ?>
                    </div>
                    <input type="hidden" name="reorder" value="ok">
                    <button type="submit" id="saveReorder" class="btn btn-success hidden">Save Reordering</button>
                	<a href="javascript:void(0);" id="menuOrder" class="btn btn-primary">Change menu order</a>
                </form>
                <div class="clearfix"></div>
			</div>
        </div> <!--/.row-->
    </section> <!-- /.content -->
    
</div> <!-- /.content-wrapper -->
  
    <div class="control-sidebar-bg"></div>
    
</div> <!-- ./wrapper -->

<?php include_once('footer.php'); ?>