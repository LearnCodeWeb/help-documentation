	
    <header class="main-header m-h">
    	<!-- Logo -->
        <a href="<?php echo SS_URL; ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b>A</b>ZCW</span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><i class="fa fa-fw fa-question-circle"></i> <strong>Help Dashboard</strong></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top navbar-fixed-top hidden-lg hidden-md hidden-sm visible-xs">
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"><span class="sr-only">Toggle navigation</span></a>
            
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                	<li><a href="<?php echo SS_URL.'menu/create-menu.html'; ?>"><i class="fa fa-fw fa-plus-circle"></i> Create Menu</a></li>
                </ul>
            </div>
        </nav>
	</header>
  	